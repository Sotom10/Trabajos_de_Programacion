<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="Inicio.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Inicio
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Horarios.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Horarios
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Matriculafinanciera.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Matricula Financiera
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Prematricula.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                Prematricula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Notas.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Notas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Materias.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Materias

          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-body-secondary text-uppercase">
            <span>Favoritos</span>
            <a class="link-secondary" aria-label="Add a new report"> <svg class="bi"><use xlink:href="#plus-circle"/></svg></a></h6>
          
              <ul class="nav flex-column mb-auto">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Solicitudestimulos.php">
                <svg class="bi"><use xlink:href="#file-earmark-text"/></svg>
                Solicitud de Estimulos 
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Semaforo.php">
                <svg class="bi"><use xlink:href="#file-earmark-text"/></svg>
                Semaforo del Estudiante
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#file-earmark-text"/></svg>
                Social engagement
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#file-earmark-text"/></svg>
                Year-end sale
              </a>
            </li>
          </ul>

          <hr class="my-3">

          <ul class="nav flex-column mb-auto">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Configuracion.php">
                <svg class="bi"><use xlink:href="#gear-wide-connected"/></svg>
                Configuración
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Salir.php">
                <svg class="bi"><use xlink:href="#door-closed"/></svg>
                Salir
              </a>
            </li>
          </ul>
        </div>
              </a>
            </li>
          </ul> 
             </div>
          </div>